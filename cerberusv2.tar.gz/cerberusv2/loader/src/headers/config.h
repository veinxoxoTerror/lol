#pragma once

#define HTTP_SERVER "138.91.32.176"
#define HTTP_PORT 80

#define TFTP_SERVER "138.91.32.176"
